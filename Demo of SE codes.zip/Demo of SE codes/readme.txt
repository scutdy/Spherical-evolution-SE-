% TEST and USAGE (matlab)
 
examples:
 
1. run SE_demo.m

or 
2. run run_image_clustering_demo.m 